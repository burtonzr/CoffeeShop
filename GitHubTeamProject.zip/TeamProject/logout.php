<html>
    <body>
        <?php
        /*
            session_start();
            $_SESSION = array();
            session_destroy();
            include("tpHome.php");
            */
            session_start();
            $_SESSION = array();
            session_destroy();
            include("tpHome.php");
        ?> 
    </body>
</html>