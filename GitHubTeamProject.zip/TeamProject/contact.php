<?php 
    include('bootstrapCode.html');
    $name = "";
    $email = "";
    $subject = "";
    $comments = "";
    if(isset($_POST['contactSubmit'])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $subject = $_POST['subject'];
        $comments = $_POST['comments'];
        
        $mailTo = "burtonzr@gmail.com";
        $headers = "From: " . $email;
        $txt = "You have recieved an email from " . $name . ".\n\n" . $comments;
        
        mail($mailTo, $subject, $txt, $headers);
        header('Location: tpHome.php');
    }

?>
<div class="jumbotron">
    <h1 class="text-center">Contact Us</h1>
</div>
<div class="container">
    <form action="contact.php" method="post">
        <div class="row pt-2">
            <div class="col-6">
                <h3>Full Name</h3>
                <input type="text" class="form-control" name="name" value="<?php echo $name; ?>" required/>
            </div>
            <div class="col-6">
                <h3>Email Address</h3>
                <input type="email" class="form-control" name="email" value="<?php echo $email; ?>" required/>
            </div>
        </div>
        <div class="row pt-2">
            <div class="col-6">
                <h3>Subject</h3>
                <input type="text" class="form-control" name="subject" value="<?php echo $subject; ?>" required/>
            </div>
            <div class="col-6">
                <h3>Message</h3><b />
                <textarea name="comments" class="form-control" value="<?php echo $comments; ?>">
                    
                </textarea>
            </div>
        </div>
        <button class="mt-3 mb-3 btn btn-default" type="submit" name="contactSubmit">Submit</button>
    </form>
    <p>
        <a href="tpHome.php" style="text-decoration: none">Go back to Home Page</a>
    </p>
</div>